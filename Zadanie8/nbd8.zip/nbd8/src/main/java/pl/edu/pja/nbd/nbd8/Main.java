package pl.edu.pja.nbd.nbd8;

import com.basho.riak.client.api.RiakClient;
import com.basho.riak.client.api.cap.Quorum;
import com.basho.riak.client.api.commands.kv.DeleteValue;
import com.basho.riak.client.api.commands.kv.FetchValue;
import com.basho.riak.client.api.commands.kv.StoreValue;
import com.basho.riak.client.core.query.Location;
import com.basho.riak.client.core.query.Namespace;
import com.basho.riak.client.core.query.RiakObject;
import com.basho.riak.client.core.util.BinaryValue;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.output.TeeOutputStream;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.concurrent.ExecutionException;

public class Main {

    private static final String RESOURCES_PATH = "src/main/resources";
    private static final String DOCUMENT_NAME = "test_document.txt";
    private static final String LOG_FILE_NAME = "komunikaty.txt";

    private static final String DOCUMENT_KEY = "document";
    private static final String BUCKET = "s22559";

    public static void main(String[] args) throws IOException, ExecutionException, InterruptedException, ObjectNotFoundException {

        //przygotowanie pliku zawierajacego komunikaty i przekierowanie stdout na plik i konsole
        prepareLogFile(RESOURCES_PATH, LOG_FILE_NAME);

        RiakClient client =
                RiakClient.newClient("localhost");

        //przygotowanie testowego dokumentu
        createTestDocument(RESOURCES_PATH, DOCUMENT_NAME);

        //pobranie testowego dokumentu z resources
        File document = getDocument(RESOURCES_PATH, DOCUMENT_NAME);

        System.out.print("Zawartosc poczatkowa pliku: ");
        printDocumentContent(document);

        //zapisanie pobranego pliku na bazie riak
        System.out.println("zapisywanie pliku...");
        riakStoreDocument(client, BUCKET, DOCUMENT_KEY, document);
        System.out.println("zapisywanie pliku: zakonczone pomyslnie");
        System.out.println("pobieranie pliku...");
        File downloadedDocument = riakGetDocument(client, BUCKET, DOCUMENT_KEY);
        System.out.println("pobieranie pliku: zakonczone pomyslnie");

        //wysietlenie zawartosci pliki
        printDocumentContent(downloadedDocument);

        //zmodyfikowanie pobranego wczesniej z bazy danych pliku
        System.out.println("modyfikowannie pliku...");
        File modifiedDocument = modifyDocument(downloadedDocument);
        System.out.println("modyfikowanie pliku: zakonczone pomylsnie");
        System.out.println("zapisywanie zmodyfikowanego pliku...");
        riakStoreDocument(client, BUCKET, DOCUMENT_KEY, modifiedDocument);
        System.out.println("zapisywanie zmodyfikowanego pliku: zakonczone pomyslnie");
        //pobranie zmodyfikowanego pliku
        System.out.println("pobieranie zmodyfikowanego pliku...");
        File downloadedModifiedDocument = riakGetDocument(client, BUCKET, DOCUMENT_KEY);
        System.out.println("pobieranie zmodyfikowanego pliku: zakonczone pomyslnie");
        //wyswietlenie zawartosci zmodyfikowanego pliku
        printDocumentContent(downloadedModifiedDocument);

        //usuniecie zmodyfikowanego pliku
        System.out.println("usuwanie zmodyfikowanego pliku...");
        riakDeleteDocument(client, BUCKET, DOCUMENT_KEY);
        System.out.println("usuwanie zmodyfikowanego pliku: zakonczone pomyslnie");
        System.out.println("pobieranie usunietego pliki...");
        try {
            File deletedDocument = riakGetDocument(client, BUCKET, DOCUMENT_KEY);
        } catch (ObjectNotFoundException e) {
            System.out.println(e.getMessage());
        }


        client.shutdown();
    }

    private static void prepareLogFile(String filePath, String fileName) throws FileNotFoundException {
        Path logFilePath = Paths.get(filePath, fileName);

        FileOutputStream fos = new FileOutputStream(logFilePath.toFile());
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            try {
                fos.flush();
            }
            catch (Throwable t) {
                // Ignore
            }
        }, "Shutdown hook Thread flushing " + logFilePath));
        TeeOutputStream myOut=new TeeOutputStream(System.out, fos);
        PrintStream ps = new PrintStream(myOut, true); //true - auto-flush after println
        System.setOut(ps);
    }

    private static void riakDeleteDocument(RiakClient client, String bucket, String key) throws ExecutionException, InterruptedException {
        Namespace ns = new Namespace("default",bucket);
        Location location = new Location(ns, key);
        DeleteValue dv = new DeleteValue.Builder(location).build();
        client.execute(dv);
    }

    private static File riakGetDocument(RiakClient client, String bucket, String key) throws ExecutionException, InterruptedException, IOException, ObjectNotFoundException {
        Namespace ns = new Namespace("default",bucket);
        Location location = new Location(ns, key);
        FetchValue fv = new FetchValue.Builder(location).build();
        FetchValue.Response response = client.execute(fv);

        if (response.isNotFound()) {
            throw new ObjectNotFoundException("Cannot find object with key: " + key);
        }

        RiakObject obj = response.getValue(RiakObject.class);
        InputStream in = new ByteArrayInputStream(obj.getValue().getValue());

        Path downloadedFilePath = Paths.get(RESOURCES_PATH, DOCUMENT_NAME);
        File downloadedFile = downloadedFilePath.toFile();

        FileUtils.copyInputStreamToFile(in, downloadedFile);

        return downloadedFile;
    }

    private static void riakStoreDocument(RiakClient client, String bucket, String key, File document) throws ExecutionException, InterruptedException, IOException {

        Namespace ns = new Namespace("default", bucket);
        Location location = new Location(ns, key);
        RiakObject riakObject = new RiakObject();
        riakObject.setValue(BinaryValue.create(FileUtils.readFileToByteArray(document)));
        StoreValue store = new StoreValue.Builder(riakObject)
                .withLocation(location)
                .withOption(StoreValue.Option.W, new Quorum(3)).build();
        client.execute(store);
    }

    private static void createTestDocument(String filePath, String fileName) throws IOException {
        Path path = Paths.get(filePath, fileName);
        File file = path.toFile();
        FileWriter writer = new FileWriter(file);
        writer.write("Dokument testowy do zadania 8. Data utworzenia: " + LocalDateTime.now());
        writer.close();
    }

    private static File getDocument(String filePath, String fileName) {
        Path path = Paths.get(filePath, fileName);
        return path.toFile();
    }

    private static File modifyDocument(File file) throws IOException {
        FileWriter writer = new FileWriter(file);
        writer.write("Plik zostal zmodyfikowany dnia: " + LocalDateTime.now());
        writer.close();
        return new File(file.getPath());
    }

    private static void printDocumentContent(File file) throws IOException {
        String data = FileUtils.readFileToString(file, StandardCharsets.UTF_8);
        System.out.println("Zawartosc dokumentu: " + data);
    }
}
